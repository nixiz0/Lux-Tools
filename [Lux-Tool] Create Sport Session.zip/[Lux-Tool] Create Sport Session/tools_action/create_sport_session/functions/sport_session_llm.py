import ollama
from kernel.tools.tools_functions.tools_action.create_sport_session.CONFIG_TOOL import *


def sport_session_llm_prompt(prompt, conversation_history):
    # Add current prompt to history
    conversation_history.append({"role": "user", "content": prompt})

    # Limit history size
    if len(conversation_history) > SPORT_SESSION_LLM_MAX_HISTORY_LENGTH:
        conversation_history.pop(0)

    # Choose the LLM Server API you want:
    """ Local Ollama (on your computer) """
    client = ollama.Client()  

    """ API Ollama (on server) """
    # client = ollama.Client(host="http://172.17.0.1:11434")

    response = client.chat(
        model=SPORT_SESSION_MODEL_NAME,
        messages=conversation_history
    )
    response_text = response['message']['content']
    
    # Add model response to history
    conversation_history.append({"role": "assistant", "content": response_text})
    
    return response_text