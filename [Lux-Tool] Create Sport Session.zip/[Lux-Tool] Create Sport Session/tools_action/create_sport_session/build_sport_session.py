import subprocess
import streamlit as st
from CONFIG import TEMP_AUDIO_PATH
from kernel.tools.tools_functions.tools_action.create_sport_session.CONFIG_TOOL import *
from kernel.tools.tools_functions.tools_action.create_sport_session.functions.auto_build_model import build_sport_session_model
from kernel.tools.tools_functions.tools_action.create_sport_session.functions.sport_session_llm import sport_session_llm_prompt
from kernel.audio.speech_to_text.record import record_audio
from kernel.audio.speech_to_text.whisper import SpeechToText
from kernel.tools.tools_functions.tools_action.create_sport_session.functions.save_history import save_sport_session
try:
    from kernel.audio.synthetic_voice.synthetic_voice import LuxVoice
except ModuleNotFoundError:
    from kernel.audio.synthetic_voice.narrator_voice import LuxVoice


conversation_history = []
def start_build_sport_session():
    global conversation_history
    whisper = SpeechToText()
    lux_voice = LuxVoice()

    # Function to activate voice only for questions or exclamations
    def lux_voice_speak(response_text):
        sentences = response_text.split('.')
        for sentence in sentences:
            if '?' in sentence.strip() or '!' in sentence.strip():
                lux_voice.speak(sentence.strip())

    st.write("Mode construction de séances de sport.." if LANGUAGE == 'fr' else "Construction mode for sports sessions..")

    # Run the 'ollama list' command and get the output
    result = subprocess.run(['ollama', 'list'], capture_output=True, text=True)
    
    # Checks if LLM_NAME is in the list of models
    if SPORT_SESSION_MODEL_NAME in result.stdout:
        pass
    else:
        st.warning(f"Modèle {SPORT_SESSION_MODEL_NAME} non trouvé. Installation.." if LANGUAGE == 'fr' else
                   f"Model {SPORT_SESSION_MODEL_NAME} not found. Installation..{SPORT_SESSION_BASE_LLM}.")
        subprocess.run(['ollama', 'pull', SPORT_SESSION_BASE_LLM])
        build_sport_session_model()

    lux_voice.speak("Quelle type de séance vous souhaitez faire ? Musculation ou Street Workout ou Crossfit" if LANGUAGE == 'fr' else 
                    "What type of session do you want to do ? Bodybuilding or Street Workout or Crossfit")

    record_audio()
    speech_transcribe = whisper.transcribe(TEMP_AUDIO_PATH)
    user_prompt_session = speech_transcribe
    st.write(user_prompt_session)

    lux_voice.speak("C'est noté Monsieur, et vous souhaitez construire une séance pour le haut du corps, le bas du corps ou pour tout le corps ?" if LANGUAGE == 'fr' else 
                    "Noted Sir, and you want to build a session for the upper body, lower body or for the whole body ?")

    record_audio()
    speech_transcribe = whisper.transcribe(TEMP_AUDIO_PATH)
    user_prompt_session_details = speech_transcribe
    st.write(user_prompt_session_details)

    # Create the pre-prompt and send it to the LLM
    pre_prompt = "je veux que tu me fasses une séance de sport pour faire " + user_prompt_session + " et j'aimerai que tu construises une séance pour " + user_prompt_session_details if LANGUAGE == 'fr' else \
                 "I want you to give me a workout to do " + user_prompt_session + " and I would like you to build a session for " + user_prompt_session_details
    st.write(pre_prompt)
    conversation_history.append({"role": "user", "content": pre_prompt})
    response_text = sport_session_llm_prompt(pre_prompt, conversation_history)
    st.write(response_text)
    lux_voice_speak(response_text)

    running = True
    skip_prompt = False
    while running:
        skip_prompt = False
        record_audio()
        speech_transcribe = whisper.transcribe(TEMP_AUDIO_PATH)
        user_prompt = speech_transcribe
        st.write(user_prompt)

        if user_prompt in ["merci", "c'est bon", "arrête le mode sport", "arrête la discussion", "tu peux arrêter", "arrête", "stop", "thanks",
                           "it's okay", "stop chat mode", "stop discussion mode", "you can stop", "stop the discussion", "you can stop"]:
            lux_voice.speak("J'arrête le mode création de séances de sports" if LANGUAGE == 'fr' else "I stop the sports session creation mode")
            running = False
            continue

        if user_prompt in ["sauvegarde", "sauvegarde ça", "sauvegarde moi ça", "sauvegarde sauvegarde", "sauvegarde moi ça"
                           "save", "save this", "save this for me", "save save"]:
            save_sport_session(conversation_history, save_last_message=True)
            lux_voice.speak("Sauvegarde de ma réponse sur votre bureau effectuée" if LANGUAGE == 'fr' else 
                            "Saved my response to your desktop")
            skip_prompt = True
            continue

        if user_prompt in ["sauvegarde moi tout ça", "sauvegarde tout", "sauvegarde globale", "sauvegarde notre discussion", 
                           "save everything for me", "save everything", "global save", "save our discussion"]:
            save_sport_session(conversation_history)
            lux_voice.speak("Sauvegarde de la discussion sur votre bureau effectuée" if LANGUAGE == 'fr' else 
                            "Saved the chat to your desktop")
            skip_prompt = True
            continue

        if not skip_prompt:
            response_text = sport_session_llm_prompt(user_prompt, conversation_history)
            st.write(response_text)
            lux_voice_speak(response_text)
        else:
            skip_prompt = False
