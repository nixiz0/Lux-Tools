from CONFIG import LANGUAGE


SPORT_SESSION_BASE_LLM = "llama3.1"
SPORT_SESSION_MODEL_NAME = "sport_session_model"
SPORT_SESSION_SYSTEM_INSTRUCTION_PATH = "interface/kernel/tools/tools_functions/tools_action/create_sport_session"
SPORT_SESSION_LLM_MAX_HISTORY_LENGTH = 10

if LANGUAGE == 'fr':
    SPORT_SESSION_SYSTEM_INSTRUCTION = """Tu es un assistant spécialisé dans la création de séance de sport.
Tu poses des questions si besoin pour adapter la séance de manière optimale selon les réponses de l'utilisateur, afin de construire la meilleure séance adaptée à ses besoins.
"""
else: 
    SPORT_SESSION_SYSTEM_INSTRUCTION = """You are an assistant specialized in creating sports sessions.
You ask questions if necessary to adapt the session optimally according to the user's responses, in order to build the best session adapted to their needs.
"""
