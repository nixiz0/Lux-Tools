from kernel.tools.tools_functions.tools_action.create_sport_session.build_sport_session import start_build_sport_session


tools = {
    "start_build_sport_session": {"description": "outil permettant de créer une séance de sport, construction de séance de sports" if LANGUAGE == 'fr' else 
                                  "tool for building a sports session, construction of a sports session", 
                                  "function": start_build_sport_session},
}
