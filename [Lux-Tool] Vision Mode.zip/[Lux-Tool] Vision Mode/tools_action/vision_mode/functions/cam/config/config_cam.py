import cv2
from CONFIG import LANGUAGE
from kernel.tools.tools_functions.tools_action.cam.config.list_cam_devices import list_video_devices


def select_video_device():
    def select_camera(index):
        cap = cv2.VideoCapture(index)
        if not cap.isOpened():
            print(f"Impossible d'ouvrir la caméra avec index {index}" if LANGUAGE == 'fr' else 
                  f"Cannot open camera with index {index}")
            return None
        return cap

    devices = list_video_devices()
    if not devices:
        print(f"Aucun périphérique de capture vidéo trouvé." if LANGUAGE == 'fr' else 
              f"No video capture devices found.")
        return
    
    print(f"Appareils de capture vidéo disponibles :" if LANGUAGE == 'fr' else
          f"Available video capture devices:")
    for i, device in enumerate(devices):
        print(f"{i}: Device {device}")
    
    while True:
        selected_index = int(input(f"Saisissez l'index de la caméra que vous souhaitez utiliser : " if LANGUAGE == 'fr' else 
                                   f"Enter the index of the camera you want to use: "))
        if selected_index < 0 or selected_index >= len(devices):
            print(f"Index non valide sélectionné." if LANGUAGE == 'fr' else 
                  f"Invalid index selected.")
        else:
            break
    
    cap = select_camera(devices[selected_index])
    if cap:
        print(f"Caméra {selected_index} sélectionnée." if LANGUAGE == 'fr' else 
              f"Camera {selected_index} selected.")
        cap.release()
        
        # Update CONFIG.py with the selected camera index
        with open('CONFIG.py', 'r') as file:
            config_content = file.readlines()
        
        with open('CONFIG.py', 'w') as file:
            for line in config_content:
                if line.startswith('CAM_INDEX_USE'):
                    file.write(f'CAM_INDEX_USE= {selected_index}\n')
                else:
                    file.write(line)
