from kernel.tools.tools_functions.tools_action.job_interview_mode.start_job_interview_mode import job_interview_mode


tools = {
    "job_interview_mode": {"description": "mode job interview qui permet de faire un entretien d'embauche pour un métier, un job" if LANGUAGE == 'fr' else 
                           "job interview mode which allows you to do a job interview for a profession, a job", 
                           "function": job_interview_mode},
}