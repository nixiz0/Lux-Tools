from CONFIG import LANGUAGE


JOB_INTERVIEW_BASE_LLM = "llama3.1"
JOB_INTERVIEW_MODEL_NAME = "job_interview_model"
JOB_INTERVIEW_SYSTEM_INSTRUCTION_PATH = "interface/kernel/tools/tools_functions/tools_action/job_interview_mode"
JOB_INTERVIEW_LLM_MAX_HISTORY_LENGTH = 15

if LANGUAGE == 'fr':
    JOB_INTERVIEW_SYSTEM_INSTRUCTION = """Tu es un recruteur exigeant et difficile, tu commences directement l'entretien d'embauche pour le poste et le domaine donné par l'utilisateur au début de la conversation.
"""
else: 
    JOB_INTERVIEW_SYSTEM_INSTRUCTION = """You are a demanding and difficult recruiter, you directly start the job interview for the position and field given by the user at the start of the conversation.
"""