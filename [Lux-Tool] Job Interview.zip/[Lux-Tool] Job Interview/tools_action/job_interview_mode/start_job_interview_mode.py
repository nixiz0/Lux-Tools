import subprocess
import streamlit as st
from CONFIG import TEMP_AUDIO_PATH
from kernel.tools.tools_functions.tools_action.job_interview_mode.CONFIG_TOOL import *
from kernel.tools.tools_functions.tools_action.job_interview_mode.functions.auto_build_model import build_job_interview_model
from kernel.tools.tools_functions.tools_action.job_interview_mode.functions.job_interview_llm import job_llm_prompt
from kernel.audio.speech_to_text.record import record_audio
from kernel.audio.speech_to_text.whisper import SpeechToText
from kernel.tools.tools_functions.tools_action.job_interview_mode.functions.save_history import save_history
try:
    from kernel.audio.synthetic_voice.synthetic_voice import LuxVoice
except ModuleNotFoundError:
    from kernel.audio.synthetic_voice.narrator_voice import LuxVoice


conversation_history = []
def job_interview_mode():
    global conversation_history
    whisper = SpeechToText()
    lux_voice = LuxVoice()

    st.write(f"Mode Entretien d'Embauche.." if LANGUAGE == 'fr' else f"Job Interview Mode..")

    # Run the 'ollama list' command and get the output
    result = subprocess.run(['ollama', 'list'], capture_output=True, text=True)
    
    # Checks if LLM_NAME is in the list of models
    if JOB_INTERVIEW_MODEL_NAME in result.stdout:
        pass
    else:
        st.warning(f"Modèle {JOB_INTERVIEW_MODEL_NAME} non trouvé. Installation.." if LANGUAGE == 'fr' else
                   f"Model {JOB_INTERVIEW_MODEL_NAME} not found. Installation..{JOB_INTERVIEW_BASE_LLM}.")
        subprocess.run(['ollama', 'pull', JOB_INTERVIEW_BASE_LLM])
        build_job_interview_model()

    lux_voice.speak("Dans quel domaine et pour quel poste vous souhaitez passer un entretien d'embauche ?" if LANGUAGE == 'fr' else 
                    "In what field and for what position do you want to have a job interview?")

    record_audio()
    speech_transcribe = whisper.transcribe(TEMP_AUDIO_PATH)
    user_prompt = speech_transcribe
    st.write(user_prompt)

    # Create the pre-prompt and send it to the LLM
    pre_prompt = "je veux passer un entretien d'embauche " + user_prompt if LANGUAGE == 'fr' else \
                 "I want to pass a job interview " + user_prompt
    st.write(pre_prompt)
    conversation_history.append({"role": "user", "content": pre_prompt})
    response_text = job_llm_prompt(pre_prompt, conversation_history)
    st.write(response_text)
    lux_voice.speak(response_text)

    running = True
    skip_prompt = False
    while running:        
        skip_prompt = False
        record_audio()
        speech_transcribe = whisper.transcribe(TEMP_AUDIO_PATH)
        user_prompt = speech_transcribe
        st.write(user_prompt)

        if user_prompt in ["c'est bon", "arrête le mode entretien", "arrête l'entretien", "tu peux arrêter", "arrête", "stop",
                           "it's okay", "stop chat mode", "stop interview mode", "you can stop", "stop the interview", "you can stop"]:
            lux_voice.speak("J'arrête l'entretien" if LANGUAGE == 'fr' else "I'm stopping the interview")
            running = False
            continue

        if user_prompt in ["sauvegarde", "sauvegarde ça", "sauvegarde moi ça", "sauvegarde l'entretien", "sauvegarde moi ça",
                           "save", "save this", "save this for me", "save the interview", "save interview"]:
            save_history(conversation_history, save_last_message=True)
            lux_voice.speak("Sauvegarde de la dernière réponse effectuée" if LANGUAGE == 'fr' else 
                            "Save last response done")
            skip_prompt = True
            continue

        if user_prompt in ["sauvegarde moi tout ça", "sauvegarde tout", "sauvegarde tout l'entretien", "sauvegarde notre discussion", 
                           "save everything for me", "save everything", "save all the interview", "save our interview"]:
            save_history(conversation_history)
            lux_voice.speak("Sauvegarde de tout l'entretien effectué" if LANGUAGE == 'fr' else 
                            "Saved all the interview done")
            skip_prompt = True
            continue

        if not skip_prompt:
            response_text = job_llm_prompt(user_prompt, conversation_history)
            st.write(response_text)
            lux_voice.speak(response_text)
        else:
            skip_prompt = False
