import os
import json
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from CONFIG import LANGUAGE, JSON_SAVE_DIR


def extract_main_words(text, number_of_words=7):
    nltk.download('punkt')
    nltk.download('stopwords')

    words = word_tokenize(text)
    if LANGUAGE == 'fr':
        main_words = [word for word in words if word.lower() not in stopwords.words('french') and word.isalpha()]
    else:
        main_words = [word for word in words if word.lower() not in stopwords.words('english') and word.isalpha()]
    return main_words[:number_of_words]

def create_filename(conversation_history):
    main_words = []
    for entry in conversation_history:
        if entry["role"] == "user":
            main_words.extend(extract_main_words(entry["content"]))
            if len(main_words) >= 7:
                break
    filename = "code_" + "_".join(main_words[:7]) + ".json"
    return filename

def save_history(conversation_history, save_last_message=False):
    if save_last_message:
        conversation_history = conversation_history[-2:]

    if not os.path.exists(JSON_SAVE_DIR):
        os.makedirs(JSON_SAVE_DIR)

    filename = create_filename(conversation_history)
    file_path = os.path.join(JSON_SAVE_DIR, filename)

    base, extension = os.path.splitext(file_path)
    counter = 1
    while os.path.exists(file_path):
        file_path = f"{base}_{counter}{extension}"
        counter += 1

    with open(file_path, mode='w', encoding='utf-8') as file:
        json.dump(conversation_history, file, ensure_ascii=False, indent=4)
    st.success(f"Conversation saved to {file_path}")
