import ollama
import re
from kernel.tools.tools_functions.tools_action.code_mode.CONFIG_TOOL import *


def code_llm_prompt(prompt, conversation_history):
    # Add current prompt to history
    conversation_history.append({"role": "user", "content": prompt})

    # Limit history size
    if len(conversation_history) > CODE_LLM_MAX_HISTORY_LENGTH:
        conversation_history.pop(0)

    # Choose the LLM Server API you want:
    """ Local Ollama (on your computer) """
    client = ollama.Client()  

    """ API Ollama (on server) """
    # client = ollama.Client(host="http://172.17.0.1:11434/")

    response = client.chat(
        model=CODE_LLM,  # Local Model
        messages=conversation_history
    )
    response_text = response['message']['content']

    # Extract code blocks from the response
    code_blocks = re.findall(r'```(.*?)```', response_text, re.DOTALL)
    code_response = "\n".join(code_blocks)
    
    # Add only the generated code to history
    conversation_history.append({"role": "assistant", "content": f"```{code_response}```"})
    
    return code_response
